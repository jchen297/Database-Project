Drop table Employees;
Drop table departments;
Drop table jobs;
Drop table Transport;
Drop table Records;
Drop table orders;
Drop table Shipments;
Drop table customers;
Drop table Products;

CREATE TABLE Customers (
     Customer_id number(8) NOT NULL,
     Customer_name char(30),
     Email char(35),
     Street_1 char(30),
     Street_2 char(30),
     zip number(5),
     city char(20),
     phone_num char(15),
     PRIMARY KEY (Customer_id)
);

CREATE TABLE Products (
     Product_id number(8) NOT NULL,
     Product_name char(30),
     Brand char(30),
     restock_price number(8,2),
     Price number(8,2),
     PRIMARY KEY (Product_id)
);

CREATE TABLE jobs (
     job_id number(8) NOT NULL ,
     job_title char(30),
     salary number(10),
     working_hour_start char(20),
     working_hour_end char(20),
     PRIMARY KEY (job_id)
);

CREATE TABLE Transport (
     Transport_id number(8) NOT NULL ,
     type char(15) NOT NULL,
     PRIMARY KEY (Transport_id)
);


CREATE TABLE Shipments (
     Shipment_id number(8) NOT NULL,
     Ship_date date,
     Employee_id number(8),
     driver_id number(8),
     Transport_id number(8),
     PRIMARY KEY (Shipment_id)
);

CREATE TABLE orders (
     order_id number(8) NOT NULL ,
     Order_date date,
     shipment_id number(8),
     customer_id number(8),
     PRIMARY KEY (order_id)
);

CREATE TABLE Records (
     Product_id number(8),
     Order_id number(8),
     Quantity number(4),
     PRIMARY KEY (order_id,Product_id)
);

CREATE TABLE departments (
     department_id number(8) NOT NULL,
     department_name char(30),
     manager_id number(8),
     PRIMARY KEY (department_id)
);

CREATE TABLE Employees (
     Employee_id number(8) NOT NULL ,
     Employee_name char(30),
     Hire_date date,
     Email char(35),
     Street_1 char(30),
     Street_2 char(30),
     zip number(5),
     city char(20),
     phone_num char(15),
     department_id number(8),
     job_id number(8),
     PRIMARY KEY (Employee_id)
);
